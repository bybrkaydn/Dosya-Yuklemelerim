const fs = require('fs');
const CronJob = require('cron').CronJob;
const config = require('./config');


var AutoAcount1 = function() {
fs.writeFile(config.acountfolder,config.acount1, function (err, data) {

    if (err) throw err;
})

console.log("Acount-1 olarak değiştirildi.")
}


new CronJob({
  cronTime: "00 00 * * *",
  onTick: AutoAcount1,
  start: true,
  timeZone: "Europe/Moscow"
});


var AutoAcount2 = function() {
    fs.writeFile(config.acountfolder,config.acount2, function (err, data) {
    
        if (err) throw err;
    })
    console.log("Acount-2 olarak değiştirildi.")
    }
    

    new CronJob({
      cronTime: "00 04 * * *",
      onTick: AutoAcount2,
      start: true,
      timeZone: "Europe/Moscow"
    });


    var AutoAcount3 = function() {
        fs.writeFile(config.acountfolder,config.acount3, function (err, data) {
        
            if (err) throw err;
        })
        console.log("Acount-3 olarak değiştirildi.")
        }
        

        new CronJob({
          cronTime: "00 08 * * *",
          onTick: AutoAcount3,
          start: true,
          timeZone: "Europe/Moscow"
        });


        var AutoAcount4 = function() {
            fs.writeFile(config.acountfolder,config.acount4, function (err, data) {
            
                if (err) throw err;
            })
            console.log("Acount-4 olarak değiştirildi.")
            }
            

            new CronJob({
              cronTime: "00 12 * * *",
              onTick: AutoAcount4,
              start: true,
              timeZone: "Europe/Moscow"
            });


            var AutoAcount5 = function() {
                fs.writeFile(config.acountfolder,config.acount5, function (err, data) {
                
                    if (err) throw err;
                })
                console.log("Acount-5 olarak değiştirildi.")
                }
                

                new CronJob({
                  cronTime: "33 16 * * *",
                  onTick: AutoAcount5,
                  start: true,
                  timeZone: "Europe/Moscow"
                });


                var AutoAcount6 = function() {
                    fs.writeFile(config.acountfolder,config.acount6, function (err, data) {
                    
                        if (err) throw err;
                    })
                    console.log("Acount-6 olarak değiştirildi.")
                    }
                    

                    new CronJob({
                      cronTime: "00 20 * * *",
                      onTick: AutoAcount6,
                      start: true,
                      timeZone: "Europe/Moscow"
                    });
