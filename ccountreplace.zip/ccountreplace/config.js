
'use strict';

module.exports = {

    acountfolder:"/root/.config/rclone/rclone.conf",
    
    acount1: '[Gdrive]\ntype = drive\nscope = drive\ntoken = {"access_token":"ya29.a0ARrdaM9-l__pC3C6sPSA-li0cz4WdyCwehENMfHDqzd91kauirn9E2hfh5Q1MPZis90NVEKM2rZXpxWk5LcXXImyjW6xEAaV4nXB05ThnAplYF_oBURWE6P14aEmBThhivoGoP8uYeGbR2vX6KZoNV09e2n3","token_type":"Bearer","refresh_token":"1//0dPmclhvplzKyCgYIARAAGA0SNwF-L9Iripameg5u2qbge_5lM3hnXoy5IVMbnPYjhOZuqvjn-9pEDN9QHpnl9dRIvne-1i9E-oM","expiry":"2021-09-10T10:15:54.602424449Z"}\nteam_drive = 0AKP08NyMNruhUk9PVA\nroot_folder_id = ',
    
    acount2:'[Gdrive]\ntype = drive\nscope = drive\ntoken = {"access_token":"ya29.a0ARrdaM-CXFscu1smKBsO1FJL0Jxfmh6VNysg8wIB0USJ44sGqpvYRVp8L4-lccHdEUfK0IybKGTB4pY3Uf-UDH1Rr4sRSHMG1nmhJXlSbkWz6fTPXuJoGSTpR2EAop73NoqRreARi7u7gdwDiHXa1uA5ePnH","token_type":"Bearer","refresh_token":"1//0dYeUXBOvX6EXCgYIARAAGA0SNwF-L9Ird7BXB-bBz617HiDgzjNbmU_EpMZ8QcBKV7JsSiGiVuuMYN-PRqbcQVEsSelRibjonTs","expiry":"2021-09-10T10:18:12.725887237Z"}\nteam_drive = 0AKP08NyMNruhUk9PVAroot_folder_id = ',
    
    acount3:'[Gdrive]\ntype = drive\nscope = drive\ntoken = {"access_token":"ya29.a0ARrdaM97-jq1TCdzqh9id3JEYd-oHYgIS8uCdhxwN1FvI88iF2N3WHIIv3SnzS_Fy52UwbiMY1hMRg3VzmE6S5ejlsaZbm_MmlDGSBFbzI-oaxa24XsVJeC1A3p1-3VlK8W5TTcqs-urAvdjCMCMQEDUH61T","token_type":"Bearer","refresh_token":"1//0dYUMFXjhq2eFCgYIARAAGA0SNwF-L9Irk--KwHx11mof-kn6SYWFHFsOITMYwZpelyQ7oa2OWxdT9W1oLFaRo3Sw2q8AaI-TCic","expiry":"2021-09-10T10:21:08.778217509Z"}\nteam_drive = 0AKP08NyMNruhUk9PVA\nroot_folder_id = ',
    
    acount4:'[Gdrive]\ntype = drive\nscope = drive\ntoken = {"access_token":"ya29.a0ARrdaM_fYf6PcFjBnHRbsjlYNk4onXg3q0T14Cv_rTwWJED3Sn3XCN3b5qw47nmQEa_90Xg3Hf0wyMBzvBB4hUru06_YNsmp1Ogi_BbxcLiIYZ93_FocU012vnFk-PVglehZ5e52xXDyDT3OxUvXwAv2ayI3","token_type":"Bearer","refresh_token":"1//0dUAZLqY7JgifCgYIARAAGA0SNwF-L9IrqiAcQkLWx6hYCfE6pHXEvayqW5N0cHxqPrLclC-aQhQP8ZgJCLHIrZj78vWmw1yZg4A","expiry":"2021-09-10T10:24:30.229528018Z"}\nteam_drive = 0AKP08NyMNruhUk9PVA\nroot_folder_id = ',
    
    acount5:'[Gdrive]\ntype = drive\nscope = drive\ntoken = {"access_token":"ya29.a0ARrdaM_PYiipk7ywQB_WXA9JFFXxypoEt5KlNKtr4rRSQbg1vsE59BNVDHaG992cazg7ZZWwtk_1kGInbmaS7RSs87xxml3ctpjoxkR2htDW8lGBPZqH_mOrFUnWU-a3Ymb6SrFaGRO-DRDXd9gmFCAGwt1N","token_type":"Bearer","refresh_token":"1//0dZ1NMWzmUeVGCgYIARAAGA0SNwF-L9IrnIeEkjHky_38oN9Pf7sXW0ZTBjVrac5pULrEYSeJghzmbFvxS_i6Cb8WzXasIt8Nq-Q","expiry":"2021-09-10T08:54:18.405582615Z"}\nteam_drive = 0AKP08NyMNruhUk9PVA\nroot_folder_id = ',
    
    acount6:'[Gdrive]\ntype = drive\nscope = drive\ntoken = {"access_token":"ya29.a0ARrdaM_y6ny3jR_AQ5-wffwUUDIJyqZhioVSqi94eenrd5sK9IEXM3jKsONnDkJDZrp7n5WUK7Di1uITsFRXaF0W4oks4obbLoPW5LJi0c9cvoLqRsIr1Aw6BI7indMC80GJ_Nqg2E_LCx2RdafRgAXF83M3","token_type":"Bearer","refresh_token":"1//0dNhWCSj-JeCZCgYIARAAGA0SNwF-L9IrVS61CaWCb4yJ2QNYz4GEeHKakD_ee23Sv2ZjienvXCtYhQRX2k8CDDwd-jod1_moEvA","expiry":"2021-09-10T09:41:21.470847242Z"}\nteam_drive = 0AKP08NyMNruhUk9PVA\nroot_folder_id = '
    

};

Object.freeze(module.exports);

