from pathlib import Path
from threading import Timer
from pyrogram import Client, filters
from pyrogram import types
from pyrogram.types import ForceReply
import configparser
import io
import glob
import os
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload
from oauth2client.transport import request
from Google import Create_Service
import pandas as pd
parser = configparser.ConfigParser()
parser.read("./config.ini")
data = parser["data"]



CLIENT_SCRET_FILE = 'credentials.json'
API_NAME = 'drive'
API_VERSION = 'v3'
SCOPES = ['https://www.googleapis.com/auth/drive']

service = Create_Service(CLIENT_SCRET_FILE, API_NAME, API_VERSION, SCOPES)

bot = Client("Echo-bot",
api_id=data.get("api_id"),
api_hash=data.get("api_hash"),
bot_token=data.get("bot_token"))

@bot.on_message(filters.command(commands=['start']) & filters.private)
def welcome(client,message):
    
    bot.send_message(message.from_user.id,"Hı")

@bot.on_message(filters.reply)
def welcome(client,message):
    path = bot.download_media(message.reply_to_message.document.file_id, block=False)
    print(path)
    # if message.text == "/gupload":
    #      files = glob.glob('./GUplaod/*')
    #      for f in files:
    #             os.remove(f)
    #      bot.send_message(message.from_user.id,"Dosya İndiriliyor.")
    #      bot.download_media(message.reply_to_message.document.file_id,'./GUplaod/'+message.reply_to_message.document.file_name)
    #      bot.send_message(message.from_user.id,"Dosya İndirildi.")
    #      filename=(str("".join(os.listdir("./GUplaod/"))))
    #      folder_id = '1v1biKotuAPfkIVuFxtC9xNN_HHvN0VjK'
    #      file_names = [filename]
    #      mime_types = [str(message.reply_to_message.document.mime_type)]
         
    #      for file_name, mime_types in zip(file_names, mime_types):
    #         file_metadata = {
    #             'name':file_name,
    #             'parents':[folder_id]
    #         }
    #         media = MediaFileUpload('./GUplaod/{0}'.format(file_name), mimetype=mime_types)
                
            # service.files().create(
            #     body=file_metadata,
            #     media_body=media,
            #     fields='id'
            # ).execute()
            # bot.send_message(message.from_user.id,"Dosya drivere yüklendi.")





bot.run()