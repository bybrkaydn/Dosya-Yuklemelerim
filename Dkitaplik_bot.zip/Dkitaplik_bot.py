import pymongo
import time
from pymongo import MongoClient
from pyrogram import Client, filters
from pyrogram import types
from PyPDF2 import PdfFileMerger
import shutil
import os
import glob
import pikepdf
import sys
sys.setrecursionlimit(7000)

try:
    cluster = MongoClient("mongodb+srv://awasdz95:146142b@cluster0.ajk7a.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
    db = cluster["myFirstDatabase"]
    kullanicis = db["kullanicis"]
    reklamkayits = db["reklamkayits"]
    reklamlinkis = db["reklamlinkis"]
    yayins = db["yayins"]
    dosyas = db["dosyas"]
    print("Bağlantı Kuruldu")
except Exception as e:
    print("Bağlantı Krulamadı")


bot = Client("Echo-bot",
api_id=1971017,
api_hash="d2648dee8c9dc2c93a4ee1d31a6fb30b",
bot_token="1900872131:AAGIyCFCEedoZ6CXmo-VfA7y_BgIJDwm5bk")



@bot.on_message(filters.command(commands=['start']) & filters.private)
def welcome(client,message):
    usermd = kullanicis.distinct('userıd')
    userlist=" ".join(str(usermd))
    userid=" ".join(str(message.from_user.id))
    if (userid in userlist):
        print("Kullanıcı Mongodb'ye kayıtlı.")
    else:
        print("Kullanıcı Mongodb'ye kayıtlı değil.")
        sample = {
            "first_name" : message.from_user.first_name,
            "last_name": message.from_user.last_name,
            "username": message.from_user.username,
            "userıd":  message.from_user.id
            }
        kullanicis.insert_one(sample)
        print("Kullanıcı Mongodb'ye kayıt edildi.")

    try:
        chatid=[-1001379065337,-1001432635826,-1001401448752,-1001794983276]
        for chat in chatid:
            status = bot.get_chat_member(chat,message.from_user.id)["status"]
            if(status=="member" or status=="creator"):
                print("Grupların Tamamına üye")
                if(len(message.command)==1):
                    bot.send_message(message.from_user.id,'**1️⃣ Bana dosya gönderirseniz telegramda kullanabilmek için bir bağlantı oluşturabilirim.** __(Sadece Yöneticiler)__**\n2️⃣ Dosya bağlantısı gönderirsen senin için bu bağlantıyı dosyaya çevirebilirim.** __(Tüm Kullanıcılar)__\n\nKomut listesi için /help\n\n__Bot edit by @TRDestekBot__',parse_mode="markdown")
                else:
                    usermd = reklamkayits.distinct('userıd')
                    userlist=" ".join(str(usermd))
                    userid=" ".join(str(message.from_user.id))
                    if (userid in userlist):
                        print("Kullanıcı reklam butonlarının en az birine basmış.")
                        ur = reklamkayits.find_one({ 'userıd': { '$regex': str(message.from_user.id) } } )
                        urc = ur["userreklam"]
                        if(urc == "1"):
                            reklam_links = reklamlinkis.find_one({})
                            link2 = str(reklam_links['reklamlinki2'])
                            link3 = str(reklam_links['reklamlinki3'])
                            link4 = str(reklam_links['reklamlinki4'])
                            button2 = types.InlineKeyboardButton(text= "👁 2. İçeriğe Göz At 👁", url= link2)
                            button3 = types.InlineKeyboardButton(text= "👁 3. İçeriğe Göz At 👁", url= link3)
                            button4 = types.InlineKeyboardButton(text= "👁 4. İçeriğe Göz At 👁", url= link4)
                            sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button2],[button3],[button4]])
                            buton_text='❗️ Kitap indirmeye devam edebilmen için aşağıdaki butonlardan sırasıyla 2,3 ve 4. içeriğe göz atıp içeriğin altında bulunan\n**✅ONAY BUTONU** na basmalısın.\n\nİçeriklere göz attıktan sonra tekrardan indirmek istediğiniz kitabın yönlendirme linkine tıklayarak indirme işlemini başlatabilirsiniz.\n\n__Bot edit by @TRDestekBot__'
                            bot.send_message(message.from_user.id, buton_text, reply_markup=sendbutton,parse_mode="markdown")                            
                        if(urc == "2"):
                            reklam_links = reklamlinkis.find_one({})
                            link3 = str(reklam_links['reklamlinki3'])
                            link4 = str(reklam_links['reklamlinki4'])
                            button3 = types.InlineKeyboardButton(text= "👁 3. İçeriğe Göz At 👁", url= link3)
                            button4 = types.InlineKeyboardButton(text= "👁 4. İçeriğe Göz At 👁", url= link4)
                            sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button3],[button4]])
                            buton_text='❗️ Kitap indirmeye devam edebilmen için aşağıdaki butonlardan sırasıyla 3. ve 4. içeriğe göz atıp içeriğin altında bulunan\n**✅ONAY BUTONU** na basmalısın.\n\nİçeriklere göz attıktan sonra tekrardan indirmek istediğiniz kitabın yönlendirme linkine tıklayarak indirme işlemini başlatabilirsiniz.\n\n__Bot edit by @TRDestekBot__'
                            bot.send_message(message.from_user.id, buton_text, reply_markup=sendbutton,parse_mode="markdown")
                        if(urc == "3"):
                            reklam_links = reklamlinkis.find_one({})
                            link4 = str(reklam_links['reklamlinki4'])
                            button4 = types.InlineKeyboardButton(text= "👁 4. İçeriğe Göz At 👁", url= link4)
                            sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button4]])
                            buton_text='❗️ Kitap indirmeye devam edebilmen için aşağıdaki butondan 4. içeriğe göz atmalısın ve içeriğin altında bulunan**✅ONAY BUTONU** na basmalısın.\n\nİçeriklere göz attıktan sonra tekrardan indirmek istediğiniz kitabın yönlendirme linkine tıklayarak indirme işlemini başlatabilirsiniz.\n\n__Bot edit by @TRDestekBot__'
                            bot.send_message(message.from_user.id, buton_text, reply_markup=sendbutton,parse_mode="markdown")
                        if(urc == "4"):
                            uniqueId = dosyas.find_one({ 'uniqueId': {'$regex': str(message.text.split("/start ")[1])}})
                            file_id = str(uniqueId['file_id'])
                            file_name = uniqueId['file_name']
                            bot.send_document(message.from_user.id,file_id,caption="📖 "+file_name+"\n\n🔎 Kitap Sorgulama: @dijitalkitap\n\n📚 Kütüphaneler: http://telegra.ph/KÜTÜPHANELER-03-28\n\n\n⚙️ Yardım ve Destek: @TRDestekBot")

                    else:
                        print("Kullanıcı reklam butonlarının hiç birine basmamış")
                        reklam_links = reklamlinkis.find_one({})
                        link1 = str(reklam_links['reklamlinki1'])
                        link2 = str(reklam_links['reklamlinki2'])
                        link3 = str(reklam_links['reklamlinki3'])
                        link4 = str(reklam_links['reklamlinki4'])
                        button1 = types.InlineKeyboardButton(text= "👁 1. İçeriğe Göz At 👁", url= link1)
                        button2 = types.InlineKeyboardButton(text= "👁 2. İçeriğe Göz At 👁", url= link2)
                        button3 = types.InlineKeyboardButton(text= "👁 3. İçeriğe Göz At 👁", url= link3)
                        button4 = types.InlineKeyboardButton(text= "👁 4. İçeriğe Göz At 👁", url= link4)
                        sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button1],[button2],[button3],[button4]])
                        buton_text='❗️ Kitap indirmeye devam edebilmen için aşağıdaki butonlara sırasıyla basarak içeriklere göz atmalısın ve içeriğin altında bulunan\n**✅ONAY BUTONU** na basmalısın.\n\nİçeriklere göz attıktan sonra tekrardan indirmek istediğiniz kitabın yönlendirme linkine tıklayarak indirme işlemini başlatabilirsiniz.\n\n__Bot edit by @TRDestekBot__'
                        bot.send_message(message.from_user.id, buton_text, reply_markup=sendbutton,parse_mode="markdown")

            break  

    except Exception as e: #Üyeliği Bulunmuyorsa

        print("Gruplardan Birine Üye değil")
        button1 = types.InlineKeyboardButton(text= "Dijital Kitap", url= "https://t.me/joinchat/UjLd-aTgXqS-WCOD")
        button2 = types.InlineKeyboardButton(text= "Roman, Hikaye & Bilim Kitapları", url= "https://t.me/joinchat/VWRJsk5tZA0t8swB")
        button3 = types.InlineKeyboardButton(text= "Eğitim Kitapları", url= "https://t.me/EgitimKitaplari")
        button4 = types.InlineKeyboardButton(text= "Duyuru Portalı", url= "https://t.me/DuyuruPortali")
        sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button1],[button2],[button3],[button4]])
        buton_text='**❗️ Bu botu kullanabilmen için aşağıdaki butonlardan 4 kanala da katılmalısın.**\n\n__Bot edit by @TRDestekBot__'
        bot.send_message(message.from_user.id, buton_text, reply_markup=sendbutton,parse_mode="markdown")



@bot.on_message(filters.command(commands=['help']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        bot.send_message(message.from_user.id,"⚙️**Komut Listesi**\n\n/help : Komut listesini açar.\n\n/stats : Kullanıcısı sayısını verir.\n\n/docup : Yayın başlatır.\n\n/send : Kullanıcılara mesaj göndermenizi sağalar.\n\n/kotares: User_id ile kullanıcı kotasını kaldırır.\n\n/kota : Tüm kullanıcıların kotalarını sıfırlar.\n\n/clearlist : Yayın listesini temizler.\n\n/rem: File_id ile dosya kaldırır.\n\n/docs : Dosyaları geri çağırır. (PDF olarak)\n\n/doclist : Dosyaların listesini verir.\n\n/yayinquantity : Yayın listesindeki dosya sayısını verir.\n\n/quantity : Kayıtlı dosya sayısını verir.\n\n/arsivpdf : PDF arşivi yükler.\n\n/arsivepub : EPUB arşivi yükler.\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.document)
def echobot(client,message):
    if(message.from_user.id==832150464):
        uniqueId_list = dosyas.distinct('uniqueId')
        userlist_str = " ".join(str(uniqueId_list))
        file_uniqeId = " ".join(str(message.document.file_unique_id))
        if (file_uniqeId in userlist_str):
            bot.send_message(message.from_user.id,"Bu dosya daha önce arşive kayıt edilmiş.")
        else:
            uniqueId_list = yayins.distinct('uniqueId')
            userlist_str = " ".join(str(uniqueId_list))
            file_uniqeId = " ".join(str(message.document.file_unique_id))
            if (file_uniqeId in userlist_str):
                bot.send_message(message.from_user.id,"Bu dosya zaten yayın listesinde.")
            else:
                sample1 = {
                    "file_name" : message.document.file_name,
                    "file_id": message.document.file_id,
                    "uniqueId": message.document.file_unique_id
                }
                dosyas.insert_one(sample1)
                sample2 = {
                    "file_name" : message.document.file_name,
                    "file_link" : "https://t.me/Dkitaplik_bot?start="+message.document.file_unique_id,
                    "uniqueId": message.document.file_unique_id
                }
                yayins.insert_one(sample2)
                bot.send_message(message.from_user.id,"**"+message.document.file_name+"**"+"\n\n"+"**File Link:** https://t.me/Dkitaplik_bot?start="+message.document.file_unique_id+"\n\n**File ID:** "+"`"+message.document.file_id+"`",parse_mode="markdown",disable_web_page_preview=True)
    else:
        bot.send_message(message.from_user.id,"**❗️ Sadece yöneticiler dosya gönderebilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")



@bot.on_message(filters.command(commands=['stats']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        usercount = str(kullanicis.count_documents({}))
        bot.send_message(message.from_user.id,"**📊Toplam Kullanıcı:** "+usercount,parse_mode="markdown")
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.command(commands=['docup']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        query = yayins.find({})
        for document in query:
            file_name=str(document['file_name'])
            file_link=str(document['file_link'])
            button1 = types.InlineKeyboardButton(text= "⬇️ İndir", url= file_link)
            button2 = types.InlineKeyboardButton(text= "❓ Nasıl İndirilir?", url= "https://imgyukle.com/f/2021/10/25/kxD7i8.jpg")
            button3 = types.InlineKeyboardButton(text= "👥 Kitabı Paylaş", url= "https://t.me/share/url?url="+file_link)
            button4 = types.InlineKeyboardButton(text= "🔗 Sorun Bildir", url= "https://t.me/TRDestekBot")
            sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button1],[button2],[button3,button4]])
            chanel_id = -1001432635826
            bot.send_message(chanel_id,"**📚 "+file_name+"**\n@dijitalkitap", reply_markup=sendbutton,parse_mode="markdown")
            time.sleep(2)
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")




@bot.on_message(filters.command(commands=['send']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464 or message.from_user.id==1141899158):
        
            index = 0
            query = kullanicis.find({})
            usercount = str(kullanicis.count_documents({}))
            totaluser=bot.send_message(message.from_user.id,"**İleti yapılacak kullanıcı Sayısı: **"+usercount)
            ilrtilenuser=bot.send_message(message.from_user.id,"**İleti yapılan kullanıcı sayısı:** 0")
            for userid in query:
                try:
                    bot.forward_messages(str(userid["userıd"]),message.chat.id,message.reply_to_message.message_id)
                    usercount = str(kullanicis.count_documents({}))
                    for_loop=str(index)
                    index += 1 
                    bot.edit_message_text(message.from_user.id,ilrtilenuser.message_id,"**İleti yapılan kullanıcı sayısı: **"+for_loop,parse_mode="markdown")
                except Exception as e:
                    sample = {
                        "userıd": str(userid["userıd"])
                        }
                    kullanicis.delete_one(sample)
                    usercount1 = str(kullanicis.count_documents({}))
                    bot.edit_message_text(message.from_user.id,totaluser.message_id,"**İleti yapılacak kullanıcı Sayısı: **"+usercount1,parse_mode="markdown")
                    time.sleep(2)

    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")



@bot.on_message(filters.command(commands=['clearlist']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        yayins.delete_many({})
        bot.send_message(message.from_user.id,"**✅ Yayın listesi temizlendi.**")
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.command(commands=['rem']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        sample = {
            'file_id': str(message.text.split("/rem ")[1])
            }
        dosyas.delete_one(sample)
        doccount = str(dosyas.count_documents({}))
        bot.send_message(message.from_user.id,"**✅ Dosya kaldırıldı\n🧮 Güncel Dosya Sayısı: **"+doccount)
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.command(commands=['docs']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        query = dosyas.find({})
        for document in query:
            file_id = str(document['file_id'])
            file_name = document['file_name']
            bot.send_document(message.from_user.id,file_id,caption="📖 "+file_name+"\n\n🔎 Kitap Sorgulama: @dijitalkitap\n\n📚 Kütüphaneler: http://telegra.ph/KÜTÜPHANELER-03-28\n\n\n⚙️ Yardım ve Destek: @TRDestekBot")
            time.sleep(2)
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.command(commands=['yayinquantity']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        yayincount = str(yayins.count_documents({}))
        bot.send_message(message.from_user.id,"**📊 Yayın Listesindeki Dosya Sayısı:** "+yayincount,parse_mode="markdown")
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.command(commands=['quantity']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        doccount = str(dosyas.count_documents({}))
        bot.send_message(message.from_user.id,"**📊 Sucucuya Kayıtlı Dosya Sayısı:** "+doccount,parse_mode="markdown")
    else:
        bot.send_message(message.from_user.id,"**❗️ Bu komutu yalnızca yetkili kişiler kullanabilir.**\n\n\n__Bot edit by @TRDestekBot__",parse_mode="markdown")


@bot.on_message(filters.command(commands=['arsivpdf']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        booklist = glob.glob("./YeniKitaplarPDF/*")
        for book in booklist:
            bookname=os.path.split(book)[-1]
            unlockpdf = pikepdf.open(book)
            unlockpdf.save('./unlockpdf/'+bookname)   
            pdfs = ['Kapak.pdf', './unlockpdf/'+bookname]
            merger = PdfFileMerger()
            for pdf in pdfs:
                merger.append(pdf,import_bookmarks=False)
            merger.write('./upload/'+bookname)
            merger.close()
            unlockpdf.close()
            os.remove(book)
            os.remove('./unlockpdf/'+bookname)
            arsivchannel = -1001731287152 
            send=bot.send_document(arsivchannel,"./upload/"+bookname)
            sample1 = {
                "file_name" : send.document.file_name,
                "file_id": send.document.file_id,
                "uniqueId": send.document.file_unique_id
                }
            dosyas.insert_one(sample1)
            file_link = "https://t.me/Dkitaplik_bot?start="+str(send.document.file_unique_id)
            file_name = str(send.document.file_name)
            button1 = types.InlineKeyboardButton(text= "⬇️ İndir", url= file_link)
            button2 = types.InlineKeyboardButton(text= "❓ Nasıl İndirilir?", url= "https://imgyukle.com/f/2021/10/25/kxD7i8.jpg")
            button3 = types.InlineKeyboardButton(text= "👥 Kitabı Paylaş", url= "https://t.me/share/url?url="+file_link)
            button4 = types.InlineKeyboardButton(text= "🔗 Sorun Bildir", url= "https://t.me/TRDestekBot")
            sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button1],[button2],[button3,button4]])
            chanel_id = -1001432635826
            bot.send_message(chanel_id,"**📚 "+file_name+"**\n@dijitalkitap", reply_markup=sendbutton,parse_mode="markdown")


@bot.on_message(filters.command(commands=['arsivepub']) & filters.private)
def welcome(client,message):
    if(message.from_user.id==832150464):
        booklist = glob.glob("./YeniKitaplarEPUB/*")
        for book in booklist:
            arsivchannel = -1001731287152
            send=bot.send_document(arsivchannel,book)
            sample1 = {
                "file_name" : send.document.file_name,
                "file_id": send.document.file_id,
                "uniqueId": send.document.file_unique_id
                }
            dosyas.insert_one(sample1)
            file_link = "https://t.me/Dkitaplik_bot?start="+str(send.document.file_unique_id)
            file_name = str(send.document.file_name)
            button1 = types.InlineKeyboardButton(text= "⬇️ İndir", url= file_link)
            button2 = types.InlineKeyboardButton(text= "❓ Nasıl İndirilir?", url= "https://imgyukle.com/f/2021/10/25/kxD7i8.jpg")
            button3 = types.InlineKeyboardButton(text= "👥 Kitabı Paylaş", url= "https://t.me/share/url?url="+file_link)
            button4 = types.InlineKeyboardButton(text= "🔗 Sorun Bildir", url= "https://t.me/TRDestekBot")
            sendbutton = types.InlineKeyboardMarkup(inline_keyboard=[[button1],[button2],[button3,button4]])
            chanel_id = -1001432635826
            bot.send_message(chanel_id,"**📚 "+file_name+"**\n@dijitalkitap", reply_markup=sendbutton,parse_mode="markdown")
            shutil.move(book, "./upload")
            time.sleep(2)


bot.run()