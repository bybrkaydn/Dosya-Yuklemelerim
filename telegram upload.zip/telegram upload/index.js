const { Telegraf } = require('telegraf')
const bot = new Telegraf("1917997105:AAGYIrjEyAShy8ywstVuUHgg8jDlsH8dEmQ");
const request = require('request');
const fs = require('fs');
const axios = require('axios');

bot.on('document', async (ctx) => {
    
    (async ()=>{

    if(`${ctx.message.document.file_size}`<=21022000){
        const file_name = `${ctx.message.document.file_name}`
        await ctx.telegram.getFileLink(`${ctx.message.document.file_id}`).then(url1 => {
            (async ()=>{
           await axios({
                method: "get",
                url: `${url1}`,
                responseType: "stream"
               
            }).then(function (response){
              response.data.pipe(fs.createWriteStream("./upload/"+file_name.split(".")[0]+" @dijitalkitap.pdf"));

        fs.readdir("./upload/", (err, files) => {

        });
    });
})()
})
}else{
    ctx.reply("Max 20mb")
    }
})()

setTimeout(function() {
    fs.readdir("./upload/", (err, files) => {
    const token = '1917997105:AAGYIrjEyAShy8ywstVuUHgg8jDlsH8dEmQ'
    const url = 'https://api.telegram.org/bot'+token+'/sendDocument'
    const chat_id = "832150464"
    
    
    let r = request(url, (err, res, body) => {
        if(err) console.log(err)
    })
    
    let f = r.form()
    
    
        f.append('chat_id', chat_id)
        f.append('document', fs.createReadStream("./upload/"+files))
    });
    }, 5000)
    setTimeout(function() {
    fs.readdir("./upload/", (err, files) => {
    fs.unlink("./upload/"+files,function(err){
        if(err) return
        ctx.reply('Dosya dizinden silindi.');
      }); 
    
    })
    }, 15000)




});




// bot.on('document', async (ctx) => {
// await ctx.telegram.getFileLink(`${ctx.message.document.file_id}`).then(url1 => {
// getImage(url1, function(err, data){
//     if(err){
//         throw new Error(err);
//     }
  
//         const fileOptions = {
//           // Explicitly specify the file name.
//           filename: 'mypdf.pdf',
//           // Explicitly specify the MIME type.
//           contentType: 'application/pdf',
//         };
//         ctx.telegram.sendDocument(ctx.chat.id, data, {}, fileOptions);
//   }); 

// })
// })

bot.launch()

            // const SCOPES = ['https://www.googleapis.com/auth/drive'];
            // const TOKEN_PATH = 'token.json';
            
            // fs.readFile('credentials.json', (err, content) => {
            //   if (err) return console.log('Error loading client secret file:', err);
            //   authorize(JSON.parse(content), uploadFile);
            // });
            
            // function authorize(credentials, callback) {
            //   const {client_secret, client_id, redirect_uris} = credentials.installed;
            //   const oAuth2Client = new google.auth.OAuth2(
            //     client_id, client_secret, redirect_uris[0]);
                
            //     fs.readFile(TOKEN_PATH, (err, token) => {
            //       if (err) return getAccessToken(oAuth2Client, callback);
            //       oAuth2Client.setCredentials(JSON.parse(token));
            //       callback(oAuth2Client);
            //     });
            //   }
              
            //   function getAccessToken(oAuth2Client, callback) {
            //     const authUrl = oAuth2Client.generateAuthUrl({
            //       access_type: 'offline',
            //       scope: SCOPES,
            //     });
                
            //     console.log('Authorize this app by visiting this url:', authUrl);
            //     const rl = readline.createInterface({
            //       input: process.stdin,
            //       output: process.stdout,
            //     });
                
            //     rl.question('Enter the code from that page here: ', (code) => {
            //       rl.close();
            //       oAuth2Client.getToken(code, (err, token) => {
            //         if (err) return console.error('Error retrieving access token', err);
            //         oAuth2Client.setCredentials(token);
                    
            //         fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
            //           if (err) return console.error(err);
            //           console.log('Token stored to', TOKEN_PATH);
            //         });
            //         callback(oAuth2Client);
            //       });
            //     });
            //   }
              
              
            //   function uploadFile(auth) {
            //     const drive = google.drive('v3');
                
   
            //       const filesMetadata = {
            //         'name': file,
            //         'parents': [config.gfolder]
            //       }
                  
            //       const media = {
            //         mimeType: 'application/plot',
            //         body: fs.createReadStream(config.upload+file)
            //       }
                  
            //       drive.files.create({
            //         auth: auth,
            //         resource: filesMetadata,
            //         media: media,
            //         fields: 'id',
            //         supportsAllDrives: true,
            //       }, err =>{
            //         if (err)console.log(err);
            //         else 
            //         console.log('Yükleme başarılı.')
			// 	  })
                
            //     }


// var https = require("https");
// var path = require("path");
// var fs = require("fs");

// // The authentication key (API Key).
// // Get your own by registering at https://app.pdf.co/documentation/api
// const API_KEY = "awasdz096@gmail.com_9c77f9b493ff19abb858868f698518bcab49";

// // Direct URL of source PDF file.
// // You can also upload your own file into PDF.co and use it as url. Check "Upload File" samples for code snippets: https://github.com/bytescout/pdf-co-api-samples/tree/master/File%20Upload/    
// const SourceFileUrl = "https://drive.google.com/file/d/1YqPStUa6sjkJBd0zjHb3GDzjnWKs1mH-/view?usp=sharing";

// // Comma-separated list of page indices (or ranges) to process. Leave empty for all pages. Example: '0,2-5,7-'.
// const Pages = "0-4";

// // PDF document password. Leave empty for unprotected documents.
// const Password = "";

// // Destination PDF file name
// const DestinationFile = "./result.pdf";

// // Image params
// const X = 400;
// const Y = 20;
// const Width = 120;
// const Height = 120;
// const ImageUrl = "https://telegra.ph/file/d7e4f9de3b4a837093887.jpg";

// // * Add image *
// // Prepare request to `PDF Edit` API endpoint
// var queryPath = `/v1/pdf/edit/add`;

// // JSON payload for api request
// var jsonPayload = JSON.stringify({
//     name: path.basename(DestinationFile),
//     password: Password,
//     url: SourceFileUrl,
//     images: [
//         {
//             url: ImageUrl,
//             x: X,
//             y: Y,
//             width: Width,
//             height: Height,
//             pages: Pages,
//         }
//     ]
// });

// var reqOptions = {
//     host: "api.pdf.co",
//     method: "POST",
//     path: queryPath,
//     headers: {
//         "x-api-key": API_KEY,
//         "Content-Type": "application/json",
//         "Content-Length": Buffer.byteLength(jsonPayload, 'utf8')
//     }
// };
// // Send request
// var postRequest = https.request(reqOptions, (response) => {
//     response.on("data", (d) => {
//         // Parse JSON response
//         var data = JSON.parse(d);

//         if (data.error == false) {
//             // Download the PDF file
//             var file = fs.createWriteStream(DestinationFile);
//             https.get(data.url, (response2) => {
//                 response2.pipe(file).on("close", () => {
//                     console.log(`Generated PDF file saved to '${DestinationFile}' file.`);
//                 });
//             });
//         }
//         else {
//             // Service reported error
//             console.log(data.message);
//         }
//     });
// }).on("error", (e) => {
//     // Request error
//     console.error(e);
// });

// // Write request data
// postRequest.write(jsonPayload);
// postRequest.end();
